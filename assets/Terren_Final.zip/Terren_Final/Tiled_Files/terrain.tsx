<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="terrain" tilewidth="1" tileheight="1" tilecount="737280" columns="1280">
 <image source="../terrain.jpg" width="1280" height="576"/>
</tileset>
